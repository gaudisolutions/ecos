package com.uniandes.gaudi.change.counter.entity;

/**
 * This enum represents the loc type
 * 
 * @class LineType.java
 * @author Felipe
 * @Date 7/04/2013
 * @since 1.0
 */
public enum LineType {

	CLASS,
	METHOD,
	COMMENT,
	REGULAR_LINE,
}
