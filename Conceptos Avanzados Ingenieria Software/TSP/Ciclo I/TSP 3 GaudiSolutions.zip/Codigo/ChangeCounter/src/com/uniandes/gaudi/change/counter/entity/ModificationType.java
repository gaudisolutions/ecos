package com.uniandes.gaudi.change.counter.entity;

/**
 * This enum represents a modification type
 * 
 * @class ModificationType.java
 * @author Felipe
 * @Date 7/04/2013
 * @since 1.0
 */
public enum ModificationType {

	FIX,
	ENHACENMENT
}
