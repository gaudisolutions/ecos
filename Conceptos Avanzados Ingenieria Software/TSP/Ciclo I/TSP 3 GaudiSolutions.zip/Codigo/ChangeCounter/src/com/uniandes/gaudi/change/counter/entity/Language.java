package com.uniandes.gaudi.change.counter.entity;

/**
 * This enum has the propertis for languages supported 
 * 
 * @class Language.java
 * @author Felipe
 * @Date 7/04/2013
 * @since 1.0
 */
public enum Language {

	JAVA
}
